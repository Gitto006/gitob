import React from 'react'

const OrderItem = () => {
  return (
    <div className='w-full h-20 bg-gray-100'>OrderItem</div>
  )
}

export default OrderItem